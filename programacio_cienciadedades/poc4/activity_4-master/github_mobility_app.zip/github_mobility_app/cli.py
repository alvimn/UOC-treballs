import typer
from github_client import GitHubClient

app = typer.Typer()

@app.command()
def buscar(query: str, lenguaje: str = None):
    client = GitHubClient()
    repos = client.buscar_repositorios(query, lenguaje)
    for repo in repos:
        print(f"{repo['full_name']} - ⭐ {repo['stargazers_count']}")
