import time

class Cache:
    def __init__(self):
        self.store = {}

    def exists(self, key):
        return key in self.store and time.time() - self.store[key]['time'] < 3600

    def get(self, key):
        return self.store[key]['data']

    def set(self, key, data):
        self.store[key] = {'data': data, 'time': time.time()}
