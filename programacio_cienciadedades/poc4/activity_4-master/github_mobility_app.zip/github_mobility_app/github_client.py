import requests
from cache import Cache

class GitHubClient:
    def __init__(self):
        self.cache = Cache()

    def buscar_repositorios(self, query, lenguaje=None):
        q = query
        if lenguaje:
            q += f" language:{lenguaje}"
        url = f"https://api.github.com/search/repositories?q={q}&sort=stars&order=desc"
        if self.cache.exists(url):
            return self.cache.get(url)
        response = requests.get(url)
        data = response.json()['items']
        self.cache.set(url, data)
        return data
