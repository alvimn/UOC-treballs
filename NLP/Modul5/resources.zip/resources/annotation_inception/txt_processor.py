import sys
from spacy.matcher import Matcher
import spacy
from cassis import *

DATE_1_THRESHOLD = 100
DATE_2_THRESHOLD = 100

print("###################################################################")
print(f"""Applying NER to set of Catalan sentences, one sentence per line. 
Stop when number of sentences with pattern 1 reach {DATE_1_THRESHOLD} 
and number of sentences with pattern 1 reach {DATE_2_THRESHOLD}.
For each sentence produce a UIMA CAS XMI file."""
)
print("###################################################################")

filename = sys.argv[1]
output_folder = sys.argv[2]

print(filename)
print(output_folder)

# Create the CAS
SENTENCE_TYPE = "de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence"
TOKEN_TYPE = "de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token"
NER_TYPE = "webanno.custom.MyLayer" # This is the Internal Name in the layer settings 

# Load our type system
with open("typesystem.xml", "rb") as f:
  ts = load_typesystem(f)



Sentence = ts.get_type(SENTENCE_TYPE)
Token = ts.get_type(TOKEN_TYPE)
NamedEntity = ts.get_type(NER_TYPE)


# Funció de suport per a imprimir un text en línies de 100 caràcters
def imprimir_per_files (text):
  """Imprimir el text subministrat com a paràmetre en files de longitud 100. 
  S'hi afegeix un regle (inici 1) per a comprovacions i es numeren les files (inici 0)

  Paràmetre:
  text: el text a imprimir per línies de longitud fixa.

  Retorn:
  retorna el text formatat amb línies de 100 caràcters i amb una línia inicial i final d'un regle que numera els caràcters.

  """
  mida_linia    = 100
  regle         = "     1-------10--------20--------30--------40--------50--------60--------70--------80--------90-------100"
  text          = text.replace("\n", " ")     # Per a que el caràcter salt de línia no salti a l'imprimir text formatat
  text          = text.replace("\r", " ")     # En textos procedents de Viquipèdia s'ha detectat caràcter '\r' que ara s'interpretaria com posicionar-se a l'inici de línia
  text_formatat = "\n".join([ f"{i//mida_linia:<5}{text[i:i+mida_linia]}"  for i in range(0, len(text), mida_linia) ])
  return regle + "\n" + text_formatat + "\n" + regle

nlp_md = spacy.load("ca_core_news_md")
matcher = Matcher(nlp_md.vocab)

# Dimecres 23 de Setembre del 2020
# Dimecres 23 de Setembre
# Dimecres 25
pattern1 = [{"LOWER":{"REGEX":r"(dilluns|dimarts|dimecres|dijous|divendres|dissabte|diumenge)"}},
          {"ORTH":{"REGEX": r"([1-9]|[12][0-9]|3[0-1])"}},
           {"ORTH":"de","OP":"?"},
           {"LOWER":{"IN":["gener","febrer","març","marc","abril","maig","juny","juliol","agost","setembre","octubre","novembre","desembre"]}, "OP": "?"},
           {"ORTH":{"REGEX": r"del?"},"OP":"?"},
            {"SHAPE": "dddd", "OP": "?"}
          ]

# 23 de Setembre del 2020
# 23 de Setembre 2020
# 23 Setembre 2020
# 23 de Setembre
# 23 Setembre
pattern2 = [{"LOWER":{"REGEX":r"(dilluns|dimarts|dimecres|dijous|divendres|dissabte|diumenge)"}, "OP": "?"},
          {"ORTH":{"REGEX": r"([1-9]|[12][0-9]|3[0-1])"}},
           {"ORTH":"de","OP":"?"},
           {"LOWER":{"IN":["gener","febrer","març","marc","abril","maig","juny","juliol","agost","setembre","octubre","novembre","desembre"]}},
           {"ORTH":{"REGEX": r"del?"},"OP":"?"},
            {"SHAPE": "dddd", "OP": "?"}
          ]

# 23/09/2020
# 23-09-2020
# 23.09.2020
# 23/9/20
pattern3 = [ {"ORTH": {"REGEX":r"([0-9]|[12][0-9]|3[0-1])[\/\-\.](0?[1-9]|1[0-2])[\/\-\.][0-9][0-9]([0-9][0-9])?"}} 
           ]

# 23/09/2020
# 23-09-2020
# 23.09.2020
# 23/9/20
pattern4 = [ {"ORTH": {"REGEX":r"([0-9]|[12][0-9]|3[0-1])"}}, # day
              {"ORTH": {"REGEX": r"[\/\-\.]"}} , # separator
              {"ORTH": {"REGEX": r"(0?[1-9]|1[0-2])"}},  # month
              {"ORTH": {"REGEX": r"[\/\-\.]"}} , # separator
              {"ORTH": {"REGEX": r"[0-9][0-9]([0-9][0-9])?"}}  # separator
           ]

#matcher.add("DATE_1", [pattern1, pattern2], greedy='LONGEST')
#matcher.add("DATE_2", [pattern3, pattern4], greedy='LONGEST')
   
if "entity_ruler" not in nlp_md.pipe_names:
  print("Seqüencia de tasques en el pipeline *abans* d'afegir entity ruler:", nlp_md.pipe_names)
  ruler = nlp_md.add_pipe("entity_ruler", before="ner")
  print("Seqüencia de tasques en el pipeline *després* d'afegir entity ruler:", nlp_md.pipe_names)
else:
    print("Seqüencia de tasques en el pipeline:", nlp_md.pipe_names)

ruler.add_patterns([{"label":"DATE_1","pattern":pattern1}, {"label":"DATE_1","pattern":pattern2},
  {"label":"DATE_2","pattern":pattern3},{"label":"DATE_2","pattern":pattern4}])


def create_annotation(doc, i):
  for sentence in doc.sents:
    cas_sentence = Sentence(begin=sentence.start_char, end=sentence.end_char)
    cas.add(cas_sentence)
    assert sentence.text == cas_sentence.get_covered_text()

  for token in doc:
    cas_token = Token(begin=token.idx, end=token.idx + len(token))
    cas.add(cas_token)
    assert token.text == cas_token.get_covered_text()

  for named_entity in doc.ents:
    cas_named_entity = NamedEntity(begin=named_entity.start_char, end=named_entity.end_char, value = named_entity.label_)
    cas.add(cas_named_entity)
    assert named_entity.text == cas_named_entity.get_covered_text()
  cas.to_xmi(f"{output_folder}/named_entities_{i}.xmi")


first = True
set_of_sentence_ids_with_date_1 = set()
set_of_sentence_ids_with_date_2 = set()
with open(filename,"r") as f:
  for i,text in enumerate(f):
    text = text.strip()
    if len(text)==0:
      continue
    cas = Cas(typesystem=ts)
    cas.sofa_string = text
    doc = nlp_md(text)
    has_date1 = False
    has_date2 = False
    for entity in doc.ents:
      if entity.label_=="DATE_1":
        has_date1 = True
      if entity.label_=="DATE_2":
        has_date2 = True
    if has_date1 and len(set_of_sentence_ids_with_date_1)<DATE_1_THRESHOLD:
      set_of_sentence_ids_with_date_1.add(i)
      create_annotation(doc,i)
    elif has_date2 and len(set_of_sentence_ids_with_date_2)<DATE_2_THRESHOLD:
      set_of_sentence_ids_with_date_2.add(i)
      create_annotation(doc,i)
    if i%1000==0:
      print(f"{i}\t{len(set_of_sentence_ids_with_date_1)}\t{len(set_of_sentence_ids_with_date_2)}")