from cassis import *
import os
import sys
import zipfile

folder = sys.argv[1]
conll_output_file = sys.argv[2]

# we unzip
for (dirpath, dirnames, filenames) in os.walk(folder):
  for filename in filenames:
    zipfilename = os.path.join(dirpath,filename)
    if zipfilename.startswith("."):
      continue
    if zipfilename.endswith(".zip"):
      with zipfile.ZipFile(zipfilename, 'r') as zip_ref:
        print(f"Unizipping {zipfilename}...")
        zip_ref.extractall(dirpath)

with open(conll_output_file, "w") as fw:
	# we process each xmi with its TypeSystem.xml and print IOB CONLL'2003 format to output file
	for (dirpath, dirnames, filenames) in os.walk(folder):
		xmi_file = None
		xml_file = None
		for filename in filenames:
			filename = os.path.join(dirpath, filename)
			if filename.endswith(".xmi"):
				xmi_file = os.path.join(dirpath, filename)
			if filename.endswith(".xml"):
				xml_file = os.path.join(dirpath, filename)
		if xmi_file is None or xml_file is None:
			continue
		with open(xml_file, 'rb') as f:
			typesystem = load_typesystem(f)
		with open(xmi_file, 'rb') as f:
			print(f"Processing {xmi_file}")
			cas = load_cas_from_xmi(f, typesystem=typesystem)
			entities = {}
			# we assume no overlapping entities
			for segment in cas.select('webanno.custom.MyLayer'):
				entities[segment.begin] = (segment.end, segment.value)
			current_index = -1
			for sentence in cas.select('de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence'):
				for token in cas.select_covered('de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token', sentence):
					entity_found = False
					for k in entities.keys():
						if current_index!=-1 and token.begin < entities[current_index][0]:
							value = entities[current_index][1]
							if value is None:
								continue
							if value.startswith("DATE"):
								value="DATE"
							fw.write(f"{token.get_covered_text()}\t\t\tI-{value}\n")
							entity_found = True
							break
						if token.begin == k:
							value = entities[token.begin][1]
							if value is None:
								continue
							if value.startswith("DATE"):
								value="DATE"
							fw.write(f"{token.get_covered_text()}\t\t\tB-{value}\n")
							entity_found = True
							current_index = k
							break
					if not entity_found:
						fw.write(f"{token.get_covered_text()}\t\t\tO\n")
						current_index = -1
				fw.write("\n") # line break for end of sentence