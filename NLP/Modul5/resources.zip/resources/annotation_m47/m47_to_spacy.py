import sys
import json
import pickle 

input_file = sys.argv[1] # fitxer anotat per m47.ai
output_file = sys.argv[2] # fitxer pickled
# Llegir fitxer anotat per m47.ai. Format del fitxer anotat en json proporcionat per m47.ai
# Es troba aquí: '/gdrive/MyDrive/UOC_NLP_Materials/Models_i_Fitxers/m47_ner.json'

with open(input_file) as fitxer:
  dades = json.load(fitxer)


# Convertir el format .json del fitxer anotat per m47.ai en format spaCy per a avaluar

exemples_anotador = []
for reg_anotat in dades:
  text = reg_anotat["Task"][0]
  anotacions = []
  for anotacio in reg_anotat["Annotators"][0]["Annotations"]:
    anotacions.append((anotacio["Start_char"], anotacio["End_char"], anotacio["Tag"]))   
  exemples_anotador.append((text, anotacions))




filehandler = open(output_file, 'wb') 
pickle.dump(exemples_anotador, filehandler)
